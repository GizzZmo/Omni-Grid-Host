import React, { useState, useEffect } from 'react';
import {
  Cpu,
  AlertTriangle,
  ShieldCheck,
  Skull,
  Tv,
  Volume2,
  Key,
  XCircle,
  Lock,
  Unlock,
  Shield,
} from 'lucide-react';
import { useAppStore } from '../store';

export const SystemCore: React.FC = () => {
  const {
    logs,
    resetAll,
    settings,
    toggleSetting,
    visibleWidgets,
    toggleWidget,
    setGeminiApiKey,
    setE2bApiKey,
    vaultStatus,
    setVaultPassphrase,
    unlockVault,
    lockVault,
    removeVaultPassphrase,
  } = useAppStore();
  const [activeTab, setActiveTab] = useState<
    'STATUS' | 'TASKS' | 'LOGS' | 'SETTINGS' | 'MANIFESTO'
  >('STATUS');
  const [memUsage, setMemUsage] = useState(0);

  // Vault passphrase form state
  const [passphrase, setPassphrase] = useState('');
  const [passphraseConfirm, setPassphraseConfirm] = useState('');
  const [vaultMessage, setVaultMessage] = useState('');
  const [vaultBusy, setVaultBusy] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setMemUsage(Math.floor(Math.random() * 30) + 20);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handlePurge = () => {
    if (confirm('WARNING: COMPLETE SYSTEM RESET. ALL LOCAL DATA WILL BE LOST. PROCEED?')) {
      window.localStorage.clear();
      resetAll();
      window.location.reload();
    }
  };

  const getFakeStats = (id: string) => {
    const sum = id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const cpu = (sum % 15) + 1;
    const mem = (sum % 120) + 10;
    return { cpu, mem, pid: sum };
  };

  const vaultLocked = vaultStatus === 'locked';
  const vaultProtected = vaultStatus !== 'unprotected';

  const handleEnablePassphrase = async () => {
    setVaultMessage('');
    if (passphrase.length < 8) {
      setVaultMessage('Passphrase must be at least 8 characters.');
      return;
    }
    if (passphrase !== passphraseConfirm) {
      setVaultMessage('Passphrases do not match.');
      return;
    }
    setVaultBusy(true);
    const result = await setVaultPassphrase(passphrase);
    setVaultBusy(false);
    if (result.ok) {
      setVaultMessage('Passphrase enabled. Vault is unlocked for this session.');
      setPassphrase('');
      setPassphraseConfirm('');
    } else {
      setVaultMessage(result.error || 'Failed to set passphrase.');
    }
  };

  const handleUnlock = async () => {
    setVaultMessage('');
    setVaultBusy(true);
    const ok = await unlockVault(passphrase);
    setVaultBusy(false);
    if (ok) {
      setVaultMessage('Vault unlocked.');
      setPassphrase('');
    } else {
      setVaultMessage('Wrong passphrase.');
    }
  };

  const handleLock = () => {
    lockVault();
    setVaultMessage('Vault locked. API keys cleared from memory.');
    setPassphrase('');
  };

  const handleRemovePassphrase = async () => {
    setVaultMessage('');
    if (!passphrase) {
      setVaultMessage('Enter current passphrase to remove protection.');
      return;
    }
    setVaultBusy(true);
    const ok = await removeVaultPassphrase(passphrase);
    setVaultBusy(false);
    if (ok) {
      setVaultMessage('Passphrase removed. Secrets auto-load on startup.');
      setPassphrase('');
      setPassphraseConfirm('');
    } else {
      setVaultMessage('Wrong passphrase — protection not removed.');
    }
  };

  const vaultStatusLabel =
    vaultStatus === 'unlocked' ? 'UNLOCKED' : vaultStatus === 'locked' ? 'LOCKED' : 'UNPROTECTED';

  const vaultStatusColor =
    vaultStatus === 'unlocked'
      ? 'text-emerald-400'
      : vaultStatus === 'locked'
        ? 'text-amber-400'
        : 'text-slate-400';

  return (
    <div className="h-full flex flex-col gap-3 font-mono">
      <div className="flex bg-slate-900/50 p-1 border border-slate-800 overflow-x-auto custom-scrollbar">
        {['STATUS', 'TASKS', 'LOGS', 'SETTINGS', 'CORE'].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab === 'CORE' ? 'MANIFESTO' : (tab as any))}
            className={`flex-1 min-w-[50px] text-[10px] font-bold py-1 px-2 transition-all whitespace-nowrap ${activeTab === (tab === 'CORE' ? 'MANIFESTO' : tab) ? 'bg-cyan-900/40 text-cyan-400 border border-cyan-500/30 shadow-[0_0_10px_rgba(6,182,212,0.2)]' : 'text-slate-600 hover:text-slate-400'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'STATUS' && (
        <div className="flex-1 flex flex-col gap-4 overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-slate-900/50 p-2 border border-slate-800 flex flex-col gap-1">
              <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
                <Cpu size={10} /> Memory
              </span>
              <div className="h-1 w-full bg-slate-800 rounded overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-500"
                  style={{ width: `${memUsage}%` }}
                ></div>
              </div>
              <span className="text-right text-xs text-emerald-400">{memUsage} MB</span>
            </div>
            <div className="bg-slate-900/50 p-2 border border-slate-800 flex flex-col gap-1">
              <span className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
                <ShieldCheck size={10} /> Vault
              </span>
              <span className={`text-xs ${vaultStatusColor} animate-pulse`}>
                {vaultStatusLabel}
              </span>
            </div>
          </div>

          <div className="bg-slate-900/50 p-2 border border-slate-800 flex flex-col gap-2">
            <div className="text-[10px] text-slate-500 uppercase flex items-center gap-2">
              <Key size={10} /> Neural Link Status
            </div>
            {vaultLocked ? (
              <div className="text-xs text-amber-400 flex items-center gap-2">
                <Lock size={12} /> Vault locked — unlock in Settings
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 text-xs">
                  <div
                    className={`w-2 h-2 rounded-full ${settings.geminiApiKey ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-red-500'}`}
                  ></div>
                  <span className="text-slate-300">
                    {settings.geminiApiKey ? 'Gemini Ready' : 'Gemini Key Missing'}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <div
                    className={`w-2 h-2 rounded-full ${settings.e2bApiKey ? 'bg-emerald-500 shadow-[0_0_5px_#10b981]' : 'bg-red-500'}`}
                  ></div>
                  <span className="text-slate-300">
                    {settings.e2bApiKey ? 'E2B Sandbox Ready' : 'E2B Key Missing'}
                  </span>
                </div>
              </>
            )}
          </div>

          <div className="bg-slate-900/50 p-2 border border-slate-800 flex items-center justify-between">
            <span className="text-[10px] text-slate-500 uppercase">Active Processes</span>
            <span className="text-xs text-cyan-400 font-bold">{visibleWidgets.length}</span>
          </div>
        </div>
      )}

      {activeTab === 'TASKS' && (
        <div className="flex-1 flex flex-col bg-black/40 border border-slate-800 rounded overflow-hidden">
          <div className="flex items-center justify-between bg-slate-900 px-2 py-1 border-b border-slate-800 text-[10px] text-slate-500 font-bold uppercase tracking-wider">
            <span className="w-10">PID</span>
            <span className="flex-1">COMMAND</span>
            <span className="w-8 text-right">CPU</span>
            <span className="w-8 text-right">MEM</span>
            <span className="w-6"></span>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {visibleWidgets.map(widgetId => {
              const stats = getFakeStats(widgetId);
              return (
                <div
                  key={widgetId}
                  className="flex items-center justify-between px-2 py-1.5 border-b border-slate-800/50 hover:bg-slate-800/30 group"
                >
                  <span className="w-10 text-[10px] text-emerald-600 font-mono">{stats.pid}</span>
                  <span className="flex-1 text-xs text-slate-300 font-bold truncate pr-2">
                    {widgetId}
                  </span>
                  <span className="w-8 text-right text-[10px] text-slate-500">{stats.cpu}%</span>
                  <span className="w-8 text-right text-[10px] text-slate-500">{stats.mem}M</span>
                  <button
                    onClick={() => toggleWidget(widgetId)}
                    className="w-6 flex items-center justify-center text-slate-600 hover:text-red-500 transition-colors"
                    title={`Kill Process ${widgetId}`}
                  >
                    <XCircle size={12} />
                  </button>
                </div>
              );
            })}
          </div>
          <div className="bg-slate-900/80 p-1 text-[10px] text-slate-600 text-center border-t border-slate-800">
            root@omni-grid:~# top -n 1
          </div>
        </div>
      )}

      {activeTab === 'LOGS' && (
        <div className="flex-1 bg-black/40 border border-slate-800 p-2 overflow-y-auto custom-scrollbar font-mono text-[10px] leading-relaxed">
          {logs.map((log, i) => (
            <div
              key={i}
              className="mb-1 border-l-2 border-slate-800 pl-2 hover:border-cyan-500/50 hover:bg-white/5 transition-colors"
            >
              <span className="text-slate-500 mr-2">{log.split(']')[0]}]</span>
              <span className="text-slate-300">{log.split(']')[1]}</span>
            </div>
          ))}
          <div className="animate-pulse text-cyan-500">_</div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="flex-1 flex flex-col gap-3 p-1 overflow-y-auto custom-scrollbar">
          <div className="flex items-center justify-between p-2 bg-slate-900/50 border border-slate-800 rounded">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Tv size={14} className="text-fuchsia-500" /> CRT Scanlines
            </div>
            <button
              onClick={() => toggleSetting('scanlines')}
              className={`w-8 h-4 rounded-full transition-colors relative ${settings.scanlines ? 'bg-fuchsia-600' : 'bg-slate-700'}`}
            >
              <div
                className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${settings.scanlines ? 'translate-x-4' : 'translate-x-0'}`}
              ></div>
            </button>
          </div>

          <div className="flex items-center justify-between p-2 bg-slate-900/50 border border-slate-800 rounded">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Volume2 size={14} className="text-cyan-500" /> System Audio
            </div>
            <button
              onClick={() => toggleSetting('sound')}
              className={`w-8 h-4 rounded-full transition-colors relative ${settings.sound ? 'bg-cyan-600' : 'bg-slate-700'}`}
            >
              <div
                className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${settings.sound ? 'translate-x-4' : 'translate-x-0'}`}
              ></div>
            </button>
          </div>

          {/* Vault passphrase */}
          <div className="flex flex-col gap-2 p-2 bg-slate-900/50 border border-violet-900/40 rounded">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <Shield size={14} className="text-violet-400" /> Vault Passphrase
              </div>
              <span className={`text-[10px] font-bold ${vaultStatusColor}`}>
                {vaultStatusLabel}
              </span>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed">
              AES-256-GCM + PBKDF2 (600k). Passphrase wraps the data key — secrets stay encrypted
              until you unlock.
            </p>

            {vaultLocked ? (
              <>
                <input
                  type="password"
                  value={passphrase}
                  onChange={e => setPassphrase(e.target.value)}
                  placeholder="Enter vault passphrase"
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:border-violet-500 focus:outline-none"
                  onKeyDown={e => e.key === 'Enter' && handleUnlock()}
                />
                <button
                  onClick={handleUnlock}
                  disabled={vaultBusy || !passphrase}
                  className="w-full py-1.5 bg-violet-800 hover:bg-violet-700 disabled:opacity-40 text-white text-xs font-bold rounded flex items-center justify-center gap-1"
                >
                  <Unlock size={12} /> {vaultBusy ? 'Unlocking…' : 'Unlock Vault'}
                </button>
              </>
            ) : (
              <>
                {!vaultProtected && (
                  <>
                    <input
                      type="password"
                      value={passphrase}
                      onChange={e => setPassphrase(e.target.value)}
                      placeholder="New passphrase (min 8 chars)"
                      className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:border-violet-500 focus:outline-none"
                    />
                    <input
                      type="password"
                      value={passphraseConfirm}
                      onChange={e => setPassphraseConfirm(e.target.value)}
                      placeholder="Confirm passphrase"
                      className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:border-violet-500 focus:outline-none"
                    />
                    <button
                      onClick={handleEnablePassphrase}
                      disabled={vaultBusy}
                      className="w-full py-1.5 bg-violet-800 hover:bg-violet-700 disabled:opacity-40 text-white text-xs font-bold rounded flex items-center justify-center gap-1"
                    >
                      <Lock size={12} /> {vaultBusy ? 'Securing…' : 'Enable Passphrase'}
                    </button>
                  </>
                )}

                {vaultProtected && vaultStatus === 'unlocked' && (
                  <div className="flex gap-2">
                    <button
                      onClick={handleLock}
                      className="flex-1 py-1.5 bg-amber-900/60 hover:bg-amber-800 text-amber-200 text-xs font-bold rounded flex items-center justify-center gap-1 border border-amber-800/50"
                    >
                      <Lock size={12} /> Lock Now
                    </button>
                    <button
                      onClick={handleRemovePassphrase}
                      disabled={vaultBusy}
                      className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded border border-slate-700"
                      title="Enter passphrase above first, then click to remove"
                    >
                      Remove
                    </button>
                  </div>
                )}

                {vaultProtected && vaultStatus === 'unlocked' && (
                  <input
                    type="password"
                    value={passphrase}
                    onChange={e => setPassphrase(e.target.value)}
                    placeholder="Current passphrase (to remove protection)"
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:border-violet-500 focus:outline-none"
                  />
                )}
              </>
            )}

            {vaultMessage && (
              <div className="text-[10px] text-violet-300 font-mono bg-violet-950/30 border border-violet-900/40 rounded px-2 py-1">
                {vaultMessage}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-2 p-2 bg-slate-900/50 border border-slate-800 rounded">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Key size={14} className="text-emerald-500" /> Gemini API Key
            </div>
            <div className="flex gap-2">
              <input
                type="password"
                value={settings.geminiApiKey}
                onChange={e => setGeminiApiKey(e.target.value.trim())}
                placeholder={vaultLocked ? 'Unlock vault first' : 'Enter Google Gemini API key'}
                disabled={vaultLocked}
                className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none disabled:opacity-40"
              />
              <button
                onClick={() => setGeminiApiKey('')}
                disabled={vaultLocked}
                className="text-[10px] px-2 py-1 bg-slate-800 text-slate-300 rounded border border-slate-700 hover:border-emerald-500 hover:text-emerald-400 transition-colors disabled:opacity-40"
              >
                Clear
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-2 p-2 bg-slate-900/50 border border-slate-800 rounded">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Key size={14} className="text-cyan-500" /> E2B API Key
            </div>
            <div className="flex gap-2">
              <input
                type="password"
                value={settings.e2bApiKey}
                onChange={e => setE2bApiKey(e.target.value.trim())}
                placeholder={vaultLocked ? 'Unlock vault first' : 'Enter E2B sandbox API key'}
                disabled={vaultLocked}
                className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 focus:border-cyan-500 focus:outline-none disabled:opacity-40"
              />
              <button
                onClick={() => setE2bApiKey('')}
                disabled={vaultLocked}
                className="text-[10px] px-2 py-1 bg-slate-800 text-slate-300 rounded border border-slate-700 hover:border-cyan-500 hover:text-cyan-300 transition-colors disabled:opacity-40"
              >
                Clear
              </button>
            </div>
          </div>

          <div className="mt-auto border border-red-900/30 p-2 bg-red-900/5 rounded">
            <div className="text-[10px] text-red-500 font-bold mb-2 flex items-center gap-1">
              <AlertTriangle size={10} /> FACTORY RESET
            </div>
            <button
              onClick={handlePurge}
              className="w-full border border-red-800/50 text-red-400 hover:bg-red-900/20 text-xs py-2 px-2 flex items-center justify-center gap-2 transition-colors uppercase tracking-widest font-bold"
            >
              <Skull size={14} /> PURGE ALL DATA
            </button>
          </div>
        </div>
      )}

      {activeTab === 'MANIFESTO' && (
        <div className="flex-1 p-2 overflow-y-auto custom-scrollbar text-xs text-slate-300 leading-6 border border-slate-800 bg-slate-900/30">
          <p className="mb-4 text-cyan-400 font-bold">{'///'} INCOMING TRANSMISSION...</p>
          <p className="mb-2">&quot;The net is vast and infinite, but your grid is your own.</p>
          <p className="mb-2">
            We built Omni-Grid because the cloud is too loud. It watches, it waits, it charges
            subscription fees for tools that should be free.
          </p>
          <p className="mb-2">
            Here, processing is local. Your thoughts are yours. The tools are sharp.
          </p>
          <p className="mb-4">Keep it clean. Keep it local. Stay disconnected.&quot;</p>
          <div className="text-right mt-4 pt-2 border-t border-slate-800 text-fuchsia-400 font-display uppercase tracking-widest">
            - Jon Constantine
          </div>
        </div>
      )}
    </div>
  );
};
